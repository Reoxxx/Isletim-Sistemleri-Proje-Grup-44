1-)
	Ethem Belka Şahin - B1812100
	Muhammed Furkan Sezgin - B1812100
	Burak Sezgin - B181210056
	Deniz İkbal Saylık - B181210041
	Ömer Buğra Aşkın - B1812100
2-)
	program.c = Programa ait kaynak kodların bulunduğu dosya 
	program.h = Programın başlık dosyası
	Makefile = Programı derleyen ve çalıştıran makefile dosyası
3-)
	Programın bulunduğu klasörde terminali açıp make yazmanız yeterli olacaktır.
4-)
	Program çalıştığında kullanıcıdan bir komut girmesini isteyecektir. Builtin komutları 		görmek için help komutunu kullanabilirsiniz. 
5-)
	Kullanıcının alınan girdiyi ayrıştırıp kodlar haline getirme işlemi yani programın parse 		fonksiyonunu yaparken çok zorlandık. İlk başta doğru gibi gözükse de farklı denemeler 		yaptığımızda hatalar alıyorduk veya yanlış bir biçimde ayrıştırıyordu.
6-)
	man komutu
	https://brennan.io/2015/01/16/write-a-shell-in-c/
	https://www.educative.io/edpresso/splitting-a-string-using-strtok-in-c
	https://iq.opengenus.org/chdir-fchdir-getcwd-in-c/
	https://stackoverflow.com/questions/298510/how-to-get-the-current-directory-in-a-c-program
