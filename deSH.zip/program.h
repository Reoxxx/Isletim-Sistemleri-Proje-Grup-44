#ifndef PROGRAM_H
#define PROGRAM_H

//Kullanılan kütüphaneler
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <limits.h>
#include <termios.h>

//Fonksiyon bildirimleri.
void deSH_loop(void);
char *deSH_read(void);
char **deSH_parse(char *line);
int deSH_cd(char **args);
int deSH_help(char **args);
int deSH_exit(char **args);
int deSH_showpid(char **args);
int deSH_execute(char **args);
int deSH_launch(char **args);

#endif
