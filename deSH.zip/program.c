#define DESH_TOK_BUFSIZE 80
#define DESH_TOK_DELIM " \t\r\n\a"
#include "program.h"

int pid_count = 5;
int *pidlist; // Olusturulan proseslerin id'sini tutan liste.
int id = 0;
char *deSH_builtin_str[] = {"cd", "help", "exit", "showpid"}; // builtin komutları
int (*deSH_builtin_func[])(char **) = {&deSH_cd, &deSH_help, &deSH_exit, &deSH_showpid};


void deSH_loop(void)//Kabuğa ait tüm fonksiyon çağrıları burada yapılır. 
{
	char *line;
	char **args;
	args = malloc(80*10*sizeof(char));
	int status = -1;
	char cwd[PATH_MAX];
	do
	{
		id++;
		getcwd(cwd, sizeof(cwd));
		printf("\x1b[38;5;80m%s sau> ",cwd ); // Prompt ekrana basılır.
		printf("\x1b[0m");
		line = deSH_read(); //Kullanıcıdan komut alınır ve line değişkenine atanır.
		args = deSH_parse(line); //Alınan komut ayrıştırılır ve args dizisine atanır.
		status = deSH_execute(args); //Komutlar yürütülür.
		free(line);
		free(args);	
	}while(status);
}
char *deSH_read(void) //Kullanıcıdan komut alınır. Char * döndürür.
{
	char *line;
	size_t size = 0;
  		if(getline(&line,&size,stdin) == -1)
  		{
  			fprintf(stderr, "sau: Okuma hatası\n");
  		}
	
  		if(strlen(line)>80)
  		{
  			fprintf(stderr, "sau: Çok fazla argüman\n");
  			line = NULL;
  		}
	
	return line;
}
char **deSH_parse(char *line) //Alınan komutu komutlar olarak ayrıştırır ve args'a(char **) herbir komutu ekler. char ** döndürür.
{
	int bufsize = DESH_TOK_BUFSIZE, position = 0;
  	char **args = malloc(bufsize * sizeof(char*));
  	char *token;

  	if (!args) {
   	 	fprintf(stderr, "sau: Bellek ayırma hatası\n");
   	 	exit(EXIT_FAILURE);
  	}

  	token = strtok(line, DESH_TOK_DELIM);
  	while (token != NULL) 
  	{
    		args[position] = token;
    		position++;

    		if (position >= bufsize) 
    		{
     	 		bufsize += DESH_TOK_BUFSIZE;
      			args = realloc(args, bufsize * sizeof(char*));
      			if (!args) 	
      			{
      	  			fprintf(stderr, "sau: Bellek ayırma hatası\n");
      	  			exit(EXIT_FAILURE);
      			}
    		}

    		token = strtok(NULL, DESH_TOK_DELIM);
 	}
  	args[position] = NULL;
	
	return args;
}



int deSH_launch(char **args) //Kullanıcı builtin komutları dışında bir komut girdiğinde burada o komut için bir child proses oluşturur ve bu prosese execvp ile komutu ve parametreleri yükler. Bu sırada waitpid ile parent prosesi bekletir.
{
	pid_t pid, wpid;
  	int status;
  	
  	pid = fork();
  	if (pid == 0) 
  	{
    		if (execvp(args[0], args) == -1) 
    		{
      			fprintf(stderr, "sau: Komut icra edilemiyor.\n");
    		}
  	  	exit(EXIT_FAILURE);
  	}
  	else if (pid < 0)
  	{
	   	 fprintf(stderr, "sau: Proses oluşturulamadı.\n");
 	}	 
 	else
 	{
    		do
    		{
    			// Bu kısım oluşan proseslerin id'sini pidlist dinamik dizisine ekler.
    			if(id == pid_count)
    			{
    				pid_count+=5;
    				pidlist = realloc(pidlist, pid_count * sizeof(int));
    			}
    			pidlist[id] = pid;
      			wpid = waitpid(pid, &status, WUNTRACED);
    		}while (!WIFEXITED(status) && !WIFSIGNALED(status));
  	}
  	return 1;
}

int deSH_cd(char **args) //Bulunan dizini değiştiren builtin komutu
{
	if (args[1] == NULL) 
	{
    		fprintf(stderr, "sau: expected argument to \"cd\"\n");
  	} 
  	else 
  	{
    		if (chdir(args[1]) != 0) 
    		{
     			fprintf(stderr, "sau: Böyle bir dosya ya da dizin yok.\n");
    		} 
  	}
  	return 1;
}

int deSH_help(char **args) // Kabuktaki builtin komutlar hakkında bilgi veren help komutu
{
	printf("\ncd     : Bulunduğunuz dizini değiştirir.\n");
	printf("help   : Kabuk komutları hakkında bilgi verir.\n");
	printf("exit   : Programdan çıkış yapar\n");
	printf("showpid: Yavru proseslerin id'sini listeler.\n\n");
}

int deSH_exit(char **args) // Kabuktan çıkış yapmak için kullanılan builtin komutu
{
	return 0;
}

int deSH_showpid(char **args) // program tarafından oluşturulmuş pproseslerin id'sini ekrana yazdıran builtin komutu
{
	for(int i=0; i<id; i++)
	{
		if(pidlist[i] != 0)
		printf("PID: %d\n",pidlist[i]);
	}
}
int deSH_execute(char **args) // Alınan komut builtin komutu ise ilgili builtin fonksiyonuna gönderir. Değilse launch fonksiyonuna gönderir ve orada o komut için proses oluşturulur.
{
	if(args[0] == NULL)
	{
		return 1;
	}
	
	for(int i=0; i< (sizeof(deSH_builtin_str)/ sizeof(char *)); i++)
	{
		if(strcmp(args[0], deSH_builtin_str[i]) == 0)
		{
			return (*deSH_builtin_func[i])(args);
		}
	}
	
	return deSH_launch(args);
}


int main()
{
	pidlist = malloc(pid_count * sizeof(int));
	pidlist[id] = getpid();
	deSH_loop();
	
	return 0;
	
	
}
